var fs = require("fs");
const { Survey } = require('enquirer');

const prompt = new Survey({
  name: 'Readme file include appropriate version',
  message: 'Sample read me generated',
  choices: [
    {
      name: 'application - used to generate, msi exe',
      message: 'This application generates sample readme file from user input'
    },
    {
      name: 'modules - ignFiles - bashscript for environment initialization ',
      message: 'Select the version'
    },
    {
      name: 'modules - loghandler - logging module ',
      message: 'Select the version.'
    },
    {
      name: ' module - inputhandler  - json input files module ',
      message: 'Select the version.'
    }
  ]
});

prompt.run()
  .then(value => console.log('ANSWERS:', value)

  fs.writeFile("Readme.md", process.argv[2], function (value) {
  if (err) {
    console.log('ANSWERS:', value);
  }
  console.log("Success!"))

  .catch (console.error);
});
