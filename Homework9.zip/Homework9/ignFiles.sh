touch ~/.gitignore 
cat > .gitignore << EOF
node_module/
.DS_Store
EOF

git config --global core.excludesFile ~/.gitignore 

cat > .gitignore
